package AS04.e02;

public class EmptyArrayException extends Exception{

    public EmptyArrayException(String statement){
        super(statement);
    }
}
