package AS04.e03;

public interface Position<E> {

    E getElement() throws IllegalStateException;

}
