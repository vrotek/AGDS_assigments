## Laufzeiten der Funktionen


### 1. first()
```O(1)```

### 2. last()
```O(1)```

### 3. before()
```O(1)```

### 4. after()
```O(1)```

### 5. size()
```O(1)```

### 6. isEmpty()
```O(1)```

### 7. addFirst()
```O(n)```

### 8. addLast()
```O(1)```

### 9. addBefore()
```O(n)```

### 10. addAfter()
```O(n)```

### 11. remove()
```O(n)```

### 12. set()
```O(n)```

### 13. iterator()
```O(n)```

### 14. positions()
```O(1)```