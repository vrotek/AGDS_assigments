## Aufgabe 3: Sortierte Zuordnungstabelle

Während der achten Vorlesung über „Suchbäume“ haben Sie auf Folie 1 (Seite 2) die Methode
higherEntry(k) des abstrakten Datentyps sortierte Zuordnungstabelle kennengelernt, die –
sofern vorhanden – das Schlüssel-Wert-Paar (k′ , v) returniert, dessen Schlüssel k′ den Nachfolger
von k darstellt.


Formulieren Sie in Pseudocode einen Algorithmus für die Methode higherEntry der auf Folie
4 (Seite 4) eingeführten Suchbaum-basierten sortierten Zuordnungstabelle.

