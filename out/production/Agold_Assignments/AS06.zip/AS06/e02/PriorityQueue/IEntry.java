package AS06.e02.PriorityQueue;

public interface IEntry<K,V> {

    K getKey();
    V getValue();

}
