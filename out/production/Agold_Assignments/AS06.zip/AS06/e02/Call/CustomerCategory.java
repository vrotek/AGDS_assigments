package AS06.e02.Call;

public enum CustomerCategory {
    Business,
    Private
}
