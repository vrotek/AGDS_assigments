package AS06.e02.Call;

public enum CallCategory {
    PaymentProblems,
    Claim
}
